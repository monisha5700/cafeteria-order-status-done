<?php
$connection = mysqli_connect("localhost", "root", "", "cart");

if (isset($_POST['reset_btn'])) {
	$dn = $_POST['reset_name'];
	$query = "UPDATE registration SET status = 'In Process' WHERE name='$dn'";
    $query_run = mysqli_query($connection, $query);
    echo $row['status'];
    header('Location: register.php');
}