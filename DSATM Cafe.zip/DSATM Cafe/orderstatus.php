<html>

<head>
    <title>Enter the Details</title>
    <link rel="icon" href="assets/imgs/logo.png" />
    <link rel="stylesheet" type="text/css" href="himanshu.css">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
            <div class="col-md-12 offset= md-1" align = "right">
                <div class="row" display="block" align = "center">
                    <div class="col-md-4 register-right offset = md-3" display="block" align = "center">
                        <img src="assets/imgs/logo.png" width="300" height="200" align = "vertical-align:middle">
                        <br>
                        <br>
                        <h2>Enter the details</h2>
                        <form action="orderstatus1.php" method="post" display="block" align = "center">
                            <br>
                            <div class="register-form">

                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Username" name="uuname">
                                </div>
                                <br>
                                <div class="form-group">
                                    <input type="password" class="form-control" placeholder="Password" name="ppname">
                                </div>
                                <br>
                                <input type="submit" value="Okay" class="btn btn-primary" name="submit">

                            </div>
                        </form>
                    </div>
                </div>
        </div>
</body>

</html>