<?php

session_start();
$un = $_SESSION['username']; 

$connection = mysqli_connect("localhost", "root", "", "cart");
$query = "SELECT * FROM registration WHERE username = '$un'";
$query_run = mysqli_query($connection, $query);
$row = mysqli_fetch_assoc($query_run);
?>


<html>

<head>
    <title>Enter the Details</title>

    <style>
    	        .btn-submit {
            position: relative;
            outline: none;
            text-decoration: none;
            border-radius: 50px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            text-transform: uppercase;
            height: 60px;
            width: 210px;
            opacity: 1;
            background-color: #ffffff;
            border: 1px solid rgba(22, 76, 167, 0.6);
        }

    	.bg-body {
            background-image: linear-gradient(to left, #e36b77, #b58b95);
        }
    </style>

</head>


<h1 align="center" style = "font-family:verdana">Your order status</h1>
<body class = "bg-body" aling = "center">
	<div class="table-responsive" position = "center">
		<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" position = "center">
                    <thead>
                        <tr align="center">
                            <th style="font-size:40px">Name </th>
                            <th style="font-size:40px">Username </th>
                            <th style="font-size:40px">Status</th>
                        </tr>
                    </thead>
                    <br> <br> <br> <br> <br> <br> <br> <br> <p></p> <p></p> 
                    <tbody style="font-family:verdana">
                    	<tr style="font-size:20px">
                    	<tr style="color:white;">
                            <td style="text-align: center;" >  <?php echo $row['name']; ?></td>
                            <td style="text-align: center;" >  <?php echo $row['username']; ?></td>
                            <td style="text-align: center;" >  <?php echo $row['status'];?></td>
                        </tr>
                        </tr>
                    </tbody>
        </table>
    </div>
</body>


<?php
echo '<br /><a href="orderstatus1.php">';
/*echo "Name: ".$row['name'];
echo "<br>";
echo "Username: ".$row['username'];
echo "<br>";
echo "Order Status: ".$row['status'];*/
?>