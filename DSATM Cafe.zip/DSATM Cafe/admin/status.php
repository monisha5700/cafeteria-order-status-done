<?php
$connection = mysqli_connect("localhost", "root", "", "cart");

if (isset($_POST['status_btn'])) {
	$dn = $_POST['status_name'];
	$query = "UPDATE registration SET status = 'Ready To Pick!' WHERE name='$dn'";
    $query_run = mysqli_query($connection, $query);
    echo $row['status'];
    header('Location: register.php');
}